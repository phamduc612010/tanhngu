import SwiftUI

struct LicenseActivationView: View {
    @ObservedObject var manager: LicenseManager

    var body: some View {
        ZStack {
            AnimatedHyperBackdrop()
                .ignoresSafeArea()

            Color.black.opacity(0.18)
                .ignoresSafeArea()

            VStack(spacing: 20) {
                Text("Nexus 3.0")
                    .font(.system(
                        size: 30,
                        weight: .black,
                        design: .rounded
                    ))
                    .foregroundStyle(.white)

                Text("Version: 1.1.0")
                    .font(.system(
                        size: 13,
                        weight: .semibold,
                        design: .rounded
                    ))
                    .foregroundStyle(.white.opacity(0.55))

                Button {
                    manager.enterMenu()
                } label: {
                    HStack(spacing: 9) {
                        Image(systemName: "arrow.right.circle.fill")
                        Text("ENTER MENU")
                    }
                    .font(.system(
                        size: 14,
                        weight: .black,
                        design: .rounded
                    ))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity, minHeight: 54)
                    .background(
                        AppTheme.accent,
                        in: RoundedRectangle(
                            cornerRadius: 17,
                            style: .continuous
                        )
                    )
                    .shadow(
                        color: AppTheme.accent.opacity(0.30),
                        radius: 14,
                        y: 7
                    )
                }
                .buttonStyle(.plain)
                .padding(.horizontal, 22)
            }
        }
        .preferredColorScheme(.dark)
    }
}